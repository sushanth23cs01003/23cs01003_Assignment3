#include<stdio.h>
#include<math.h>
int main(){
int a;
printf("enter the number:\n");
scanf("%d",&a);
int b; 
b = pow(a,2);
int c ;
c = b/100;
int d;
d = b/1000;
int g;
g =d;
int e;
 e = b-(g*1000);
 int f;
 f = c+e;

if(f == a){
    printf("given number is kaprekar number");
}
 else{
    printf("it is not kaprekar number");
 }
    return 0;
}