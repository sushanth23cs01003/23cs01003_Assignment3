#include<stdio.h>
int main(){
int day;
printf("enter the days:");
scanf("%d",&day);
if(day<=5)
printf("your fine 1 rupee");
if(day>=6&&day<=10)
printf("your fine 2 rupee");
if(day>10&&day<=30)
printf("your fine 5 rupees");
else if(day>30)  {

    printf("your membership is cancelled");
}

 











    return 0;
}


