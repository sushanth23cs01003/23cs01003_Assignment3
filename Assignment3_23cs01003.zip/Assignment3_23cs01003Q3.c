#include<stdio.h>

int main(){

int a,b,c;
printf("enter the values of sides of triangle");

scanf("%d",&a);
scanf("%d",&b);
scanf("%d",&c);
if(a+b>c&&a+c>b)
printf("it forms triangle");

else {

    printf("it does not triangle");
}







    return 0;
}

