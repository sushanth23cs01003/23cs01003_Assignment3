#include<stdio.h>
int main(){

int a,b,c;
printf("enter the a,b,c values");
scanf("%d%d%d",&a,&b,&c);

if(a>b&&a>c)
printf("greatest of these numbers is %d",a);

else if(b>a&&b>c)
printf("greatest of these numbeers is %d",b);

else{

    printf("greatest of these numbers is %d",c);
}











    return 0;
}







