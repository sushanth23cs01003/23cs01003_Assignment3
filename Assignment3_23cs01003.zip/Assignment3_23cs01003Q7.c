#include<stdio.h>
int main(){

float T,M,W;
int N,K ;
printf("enter  the values of M,N,K");
scanf("%f%d%d",&M,&N,&K);
W = N/K;
T = M*W;
if(T>=90)
printf("your grade is EX");
if( T>=80 &&T<89)
printf("your grade is A");
if( T >=70 && T<79)
printf("your grade is  B");
if(T>=60&&T<69)
printf("your grade is C");
if(T>=50&&T<59)
printf("your grade is D");
if(T>=40&&T<49)
printf("your grade is P");
if (T<40)
printf("your grade is F");
    return 0;
}




